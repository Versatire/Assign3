package com.example.y_polika.assign3_db.ACTIVITIES_DB;

import com.example.y_polika.assign3_db.COURSE_DB.CConfig;

public class AConfig extends CConfig {

    public static final String ASSIGNDB_NAME = "assign-db";

    public static final int ASSIGNDB_VERSION = 1;

    public static final String ASSIGN_TABLE_NAME = "assigns";

    public static final String COLUMN_ASSIGN_ID = "assign-id";
    public static final String COLUMN_ACOURSE_ID = "acourse-id";
    public static final String COLUMN_ASSIGN_TITLE = "assign-title";
    public static final String COLUMN_ASSIGN_GRADE = "assign-grade";
}
