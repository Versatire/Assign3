package com.example.y_polika.assign3_db.ACTIVITIES_DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import com.example.y_polika.assign3_db.Assignmen;
import com.example.y_polika.assign3_db.COURSE_DB.CConfig;
import com.example.y_polika.assign3_db.COURSE_DB.CDBHelper;
import com.example.y_polika.assign3_db.Courses;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class ADBHelper extends SQLiteOpenHelper {

    private static final String TAG = "AssignmentDBeHelper";

    private Context context;

    public ADBHelper(Context context) {
        super(context, AConfig.ASSIGNDB_NAME, null, AConfig.ASSIGNDB_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_TABLE_ASSIGN = " CREATE TABLE " + AConfig.ASSIGN_TABLE_NAME +
                " ( " + AConfig.COLUMN_ASSIGN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + AConfig.COLUMN_COURSE_ID + " INTEGER NOT NULL " + AConfig.COLUMN_ASSIGN_TITLE +
                " TEXT NOT NULL " + AConfig.COLUMN_ASSIGN_GRADE + "  ) ";

        Log.d(TAG, CREATE_TABLE_ASSIGN);
        db.execSQL(CREATE_TABLE_ASSIGN);
        Log.d(TAG, "Assignments database created");
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    public long insertAssignment(Assignmen assign){

        long id = -1;
        //
        SQLiteDatabase assigndbwrite = this.getWritableDatabase();

        ContentValues assignValues = new ContentValues();
        assignValues.put(AConfig.COLUMN_COURSE_ID, assign.getCourseCode());
        assignValues.put(AConfig.COLUMN_ASSIGN_TITLE, assign.getAssignTitle());
        assignValues.put(AConfig.COLUMN_ASSIGN_GRADE, assign.getAssignGrade());

        try {
            /* passes the courseValues with insertOrThrow funchtion into COURSE_TABLE_NAME  or throws an exception */
            id = assigndbwrite.insertOrThrow(AConfig.COURSE_TABLE_NAME, null, assignValues);
        }
        catch (SQLiteException e) {
            /* or catches exception, logs it and pops up a message */
            Log.d(TAG, "EXCEPTION: " + e);
            Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
        }
        finally {
            /* closes the database */
            assigndbwrite.close();
        }
// at the end returns id of the course entry created in the table
        return id;
    }



    // Read a list of all courses and gets all the courses stored in courseDB
    public List<Assignmen> getAllAssignments() {
// Opens a readable database
        SQLiteDatabase assigndbread = this.getReadableDatabase();
        Cursor cursor = null;

        try {
// query function opens a cursor pointing at a specific row matching the parameters.
// Here starts at 1st row, then goes through every row and retries each course
            cursor = assigndbread.query(AConfig.ASSIGN_TABLE_NAME, null, null, null, null, null, null);

            if (cursor != null) {
                if (cursor.moveToFirst()) {
// Creates a new array to store the values read from the course table
                    List<Assignmen> assignmenList = new ArrayList<>();
                    do {
                        int assignId = cursor.getInt(cursor.getColumnIndex(AConfig.COLUMN_ASSIGN_ID));
                        String courseCode = cursor.getString(cursor.getColumnIndex(AConfig.COLUMN_COURSE_ID));
                        String assignTitle = cursor.getString(cursor.getColumnIndex((AConfig.COLUMN_ASSIGN_TITLE)));
                        int assignGrade = cursor.getInt(cursor.getColumnIndex(AConfig.COLUMN_ASSIGN_GRADE));

                        assignmenList.add(new Assignmen(assignId, courseCode, assignTitle, assignGrade));

                    } while (cursor.moveToNext());

                    return assignmenList;
                }
            }
        } catch (SQLiteException e) {
            /* or catches exception, logs it and pops up a message */
            Log.d(TAG, "EXCEPTION: " + e);
            Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            assigndbread.close();
        }
        return Collections.emptyList();
    }

    public int getAssGradeAverage()
    {
        // Opens a readable database
        SQLiteDatabase assigndbread = this.getReadableDatabase();
        Cursor cursor = null;
        int assGradeAve = 0;

        try
        {
// query function opens a cursor pointing at a specific row matching the parameters.
// Here starts at 1st row, then goes through every row and retries each course
            cursor = assigndbread.query(AConfig.ASSIGN_TABLE_NAME, null, null, null, null, null, null);

            if (cursor != null)
            {
                if (cursor.moveToFirst())
                {
// Creates a new array to store the values read from the course table

                    int i = 1;
                    int assignGradeTotal = 0;
                    int assignGradeAve;
                    do
                     {

                        assignGradeTotal = assignGradeTotal + cursor.getInt(cursor.getColumnIndex(AConfig.COLUMN_ASSIGN_GRADE));

                        assignGradeAve = assignGradeTotal/i;
                        i++;

                    } while (cursor.moveToNext());

                    assGradeAve = assignGradeAve;
                    return assignGradeAve;
                }
            }
        } catch (SQLiteException e)
        {
            /* or catches exception, logs it and pops up a message */
            Log.d(TAG, "EXCEPTION: " + e);
            Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
        } finally
        {
            if (cursor != null)
            {
                cursor.close();
            }
            assigndbread.close();
        }
        return assGradeAve;
    }



    public int getCourseGradeAverage(int courseIdIndex)
    {

        int courseGradeAve = 0;
        int assignGradeTot = 0;
        int i = 0;

        // Opens a readable database
        SQLiteDatabase assigndbread = this.getReadableDatabase();
        Cursor cursor = null;

        try
        {
// query function opens a cursor pointing at a specific row matching the parameters.
// Here starts at 1st row, then goes through every row and retries each course
            cursor = assigndbread.query(AConfig.ASSIGN_TABLE_NAME, null, null, null, null, null, null);
            List<Assignmen> assignmenList = new ArrayList<>();

            if (cursor != null)
            {
                if (cursor.moveToFirst())
                {
// Creates a new array to store the values read from the course table


                    do
                    {
                        int courseId = cursor.getInt(cursor.getColumnIndex(AConfig.COLUMN_COURSE_ID));

                        int grade = cursor.getInt(cursor.getColumnIndex(AConfig.COLUMN_ASSIGN_GRADE));


                        if(courseId==courseIdIndex)
                        {
                            assignGradeTot = assignGradeTot + grade;
                            i++;
                        }

                    }  while (cursor.moveToNext());

                }
            }

            courseGradeAve = assignGradeTot/i;
            return courseGradeAve;
        }
        catch (SQLiteException e)
        {
            /* or catches exception, logs it and pops up a message */
            Log.d(TAG, "EXCEPTION: " + e);
            Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
        }
        finally
        {
            if (cursor != null)
            {
                cursor.close();
            }
            assigndbread.close();
        }

        return courseGradeAve;
    }




    public Assignmen getAssignByCourseId(String courseIdstr)
    {
        // Opens a readable database
        SQLiteDatabase assigndbread = this.getReadableDatabase();
        Cursor cursor = null;
        int indexId = Integer.parseInt(courseIdstr);

        try
        {
// query function opens a cursor pointing at a specific row matching the parameters.
// Here starts at 1st row, then goes through every row and retries each course
            cursor = assigndbread.query(AConfig.ASSIGN_TABLE_NAME, null, CConfig.COLUMN_COURSE_ID + " = ? ", new String[]{courseIdstr}, null, null, null);

            if (cursor != null)
            {
                if (cursor.moveToFirst())
                {


// Read the row matching the condition
                        int id = cursor.getInt(cursor.getColumnIndex(AConfig.COLUMN_ASSIGN_ID));
                        String courseCode = cursor.getString(cursor.getColumnIndex(AConfig.COLUMN_COURSE_ID));
                        String title = cursor.getString(cursor.getColumnIndex(AConfig.COLUMN_ASSIGN_TITLE));
                        int grade = cursor.getInt(cursor.getColumnIndex(AConfig.COLUMN_ASSIGN_GRADE));

// Creates a new object of class courses with parameters id, title, code to store read values
                        return new Assignmen(id, courseCode, title, grade);

                }
            }

        }
        catch (SQLiteException e)
        {
            /* or catches exception, logs it and pops up a message */
            Log.d(TAG, "EXCEPTION: " + e);
            Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
        }
        finally
        {
            if (cursor != null)
            {
                cursor.close();
            }
            assigndbread.close();
        }

        return null;
    }


        public List<Assignmen> getAllAssignsByCourseId(String courseIdIndex) {
// Opens a readable database
            SQLiteDatabase assigndbread = this.getReadableDatabase();
            Cursor cursor = null;

            try
            {
// query function opens a cursor pointing at a specific row matching the parameters.
// Here starts at 1st row, then goes through every row and retries each course
                cursor = assigndbread.query(AConfig.ASSIGN_TABLE_NAME, null, null, null, null, null, null);
                List<Assignmen> assignmenList = new ArrayList<>();

                if (cursor != null)
                {
                    if (cursor.moveToFirst())
                    {
// Creates a new array to store the values read from the course table

                        do {
                                int assignId = cursor.getInt(cursor.getColumnIndex(AConfig.COLUMN_ASSIGN_ID));
                                String courseCode = cursor.getString(cursor.getColumnIndex(AConfig.COLUMN_COURSE_ID));
                                String assignTitle = cursor.getString(cursor.getColumnIndex(AConfig.COLUMN_ASSIGN_TITLE));
                                int assignGrade = cursor.getInt(cursor.getColumnIndex(AConfig.COLUMN_ASSIGN_GRADE));

                                if(courseCode==courseIdIndex) {
                                assignmenList.add(new Assignmen(assignId, courseCode, assignTitle, assignGrade));
                                }

                        }  while (cursor.moveToNext());

                    }
                }
                return assignmenList;
            }
            catch (SQLiteException e)
            {
                /* or catches exception, logs it and pops up a message */
                Log.d(TAG, "EXCEPTION: " + e);
                Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
            }
            finally
            {
                if (cursor != null)
                {
                    cursor.close();
                }
                assigndbread.close();
            }
            return Collections.emptyList();
        }

    }

