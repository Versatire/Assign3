package com.example.y_polika.assign3_db;


public class Assignmen extends Courses {


    private Integer AssignID;
    private String CourseCode;
    private String AssignTitle;
    private Integer AssignGrade;


    public Assignmen(String code, String assignTitle, Integer assignGrade) {
        super(code);
        AssignTitle = assignTitle;
        AssignGrade = assignGrade;
    }

    public Assignmen(Integer assignID, String code,  String assignTitle, Integer assignGrade) {
        super(code);
        AssignID = assignID;
        AssignTitle = assignTitle;
        AssignGrade = assignGrade;
    }

    public Assignmen(String title, String code, Integer assignID, String courseCode, String assignTitle, Integer assignGrade) {
        super(title, code);
        AssignID = assignID;
        CourseCode = courseCode;
        AssignTitle = assignTitle;
        AssignGrade = assignGrade;
    }

    public Assignmen(String code, Integer assignID, String courseCode, String assignTitle, Integer assignGrade) {
        super(code);
        AssignID = assignID;
        CourseCode = courseCode;
        AssignTitle = assignTitle;
        AssignGrade = assignGrade;
    }

    public Assignmen(Integer id, Integer assignID, String courseCode, String assignTitle, Integer assignGrade) {
        super(id);
        AssignID = assignID;
        CourseCode = courseCode;
        AssignTitle = assignTitle;
        AssignGrade = assignGrade;
    }

    public Integer getAssignID() {
        return AssignID;
    }

    public void setAssignID(Integer assignID) {
        AssignID = assignID;
    }

    public String getCourseCode() {
        return CourseCode;
    }

    public void setCourseCode(String courseCode) {
        CourseCode = courseCode;
    }

    public String getAssignTitle() {
        return AssignTitle;
    }

    public void setAssignTitle(String assignTitle) {
        AssignTitle = assignTitle;
    }

    public Integer getAssignGrade() {
        return AssignGrade;
    }

    public void setAssignGrade(Integer assignGrade) {
        AssignGrade = assignGrade;
    }
}

