package com.example.y_polika.assign3_db.COURSE_DB;

public class CConfig {

    public static final String COURSEDB_NAME = "courses-db";
    public static final int COURSEDB_VERSION = 1;

    public static final String COURSE_TABLE_NAME = "courses";

    public static final String COLUMN_COURSE_ID = "_id";
    public static final String COLUMN_COURSE_TITLE = "title";
    public static final String COLUMN_COURSE_CODE = "code";

}
