package com.example.y_polika.assign3_db.COURSE_DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import com.example.y_polika.assign3_db.Courses;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CDBHelper extends SQLiteOpenHelper {

    public static String clickedCourseCode = null;

    private Context context;

    private static final String TAG = "CourseDBHelper";

    public CDBHelper(Context context) {
/* an instant of CDBHelper of class context, which takes parameters of
   CourseDB Name and CourseDB Version
   used later to keep track of the database version and make sure the newer one is used */

        super(context, CConfig.COURSEDB_NAME, null, CConfig.COURSEDB_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        /* Create a table (once only when the application first runs) to store COURSES
         *  with columns holding values of COURSE_ID, COURSE_NAME, COURSE_CODE
         *  and with rows holding entries of courses, where ID is auto incremented */
        String CREATE_TABLE_COURSE = "CREATE TABLE " + CConfig.COURSE_TABLE_NAME + " ( "
                + CConfig.COLUMN_COURSE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + CConfig.COLUMN_COURSE_TITLE + " TEXT NOT NULL, "
                + CConfig.COLUMN_COURSE_CODE + " TEXT NOT NULL)";

        /* Outputs logs for testing whether the database table was created correctly for debugging */
        Log.d(TAG, CREATE_TABLE_COURSE);

        db.execSQL(CREATE_TABLE_COURSE);

        Log.d(TAG, "Courses database created");
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    /* Creates insertCourses function which could be reused to add courses to CourseDB*/
    public long insertCourse(Courses courses) {

        long id = -1;

        /* Opens CourseDB in write mode */
        SQLiteDatabase coursedbwrite = this.getWritableDatabase();

// Creates content values instant called courseValues for title and code to be put into the database
        ContentValues courseValues = new ContentValues();
        courseValues.put(CConfig.COLUMN_COURSE_TITLE, courses.getTitle());
        courseValues.put(CConfig.COLUMN_COURSE_CODE, courses.getCode());

/* Adding courseValues to courseDB and reading from db is done inside try() and catch()
   functions to catch any errors or exceptions */
        try {
            /* passes the courseValues with insertOrThrow funchtion into COURSE_TABLE_NAME  or throws an exception */
            id = coursedbwrite.insertOrThrow(CConfig.COURSE_TABLE_NAME, null, courseValues);
        }
        catch (SQLiteException e) {
            /* or catches exception, logs it and pops up a message */
            Log.d(TAG, "EXCEPTION: " + e);
            Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
        }
        finally {
            /* closes the database */
            coursedbwrite.close();
        }
// at the end returns id of the course entry created in the table
        return id;
    }


    // Read a list of all courses and gets all the courses stored in courseDB
    public List<Courses> getAllCourses() {
// Opens a readable database
        SQLiteDatabase coursedbread = this.getReadableDatabase();
        Cursor cursor = null;

        try {
// query function opens a cursor pointing at a specific row matching the parameters.
// Here starts at 1st row, then goes through every row and retries each course
            cursor = coursedbread.query(CConfig.COURSE_TABLE_NAME, null, null, null, null, null, null);

            if (cursor != null) {
                if (cursor.moveToFirst()) {
// Creates a new array to store the values read from the course table
                    List<Courses> courses = new ArrayList<>();
                    do {
                        int id = cursor.getInt(cursor.getColumnIndex(CConfig.COLUMN_COURSE_CODE));
                        String title = cursor.getString(cursor.getColumnIndex((CConfig.COLUMN_COURSE_TITLE)));
                        String code = cursor.getString(cursor.getColumnIndex(CConfig.COLUMN_COURSE_CODE));

                        courses.add(new Courses(id, title, code));

                    } while (cursor.moveToNext());
                    return courses;
                }
            }
        } catch (SQLiteException e) {
            /* or catches exception, logs it and pops up a message */
            Log.d(TAG, "EXCEPTION: " + e);
            Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            coursedbread.close();
        }
        return Collections.emptyList();
    }


    public Courses getCourseByCode(String courseCode) {
        // Opens a readable database
        SQLiteDatabase coursedbread = this.getReadableDatabase();
        Cursor cursor = null;

        try {
// query function opens a cursor pointing at a specific row matching the parameters.
// Here starts at 1st row, then goes through every row and retries each course
            cursor = coursedbread.query(CConfig.COURSE_TABLE_NAME, null, CConfig.COLUMN_COURSE_CODE + " = ? ", new String[]{courseCode}, null, null, null);

            if (cursor != null) {

// Read the row matching the condition
                    int id = cursor.getInt(cursor.getColumnIndex(CConfig.COLUMN_COURSE_ID));
                    String title = cursor.getString(cursor.getColumnIndex((CConfig.COLUMN_COURSE_TITLE)));
                    String code = cursor.getString(cursor.getColumnIndex(CConfig.COLUMN_COURSE_CODE));
// Creates a new object of class courses with parameters id, title, code to store read values
                    return new Courses(id, title, code);

            }

        } catch (SQLiteException e) {
            /* or catches exception, logs it and pops up a message */
            Log.d(TAG, "EXCEPTION: " + e);
            Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            coursedbread.close();
        }

        return null;
    }


    public String getCodeByID(int courseId) {
        String str = "" +courseId;
        // Opens a readable database
        SQLiteDatabase coursedbread = this.getReadableDatabase();
        Cursor cursor = null;
        cursor = (Cursor) coursedbread.query(CConfig.COURSE_TABLE_NAME, null, CConfig.COLUMN_COURSE_CODE + " = ? ", new String[]{str}, null, null, null);

        if (cursor != null) {
            cursor.moveToPosition(courseId);
            String code = cursor.getString(cursor.getColumnIndex(CConfig.COLUMN_COURSE_CODE));
            clickedCourseCode = code;
            cursor.close();
        }
        return clickedCourseCode;
    }


}


