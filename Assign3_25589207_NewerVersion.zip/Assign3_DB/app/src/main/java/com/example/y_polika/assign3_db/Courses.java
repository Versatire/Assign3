package com.example.y_polika.assign3_db;

public class Courses {
    private Integer Id;
    private String Title;
    private String Code;

    public Courses(Integer id, String title, String code) {
        this.Id = id;
        Title = title;
        Code = code;
    }

    public Courses(String title, String code) {
        Title = title;
        Code = code;
    }

    public Courses(String code) {
        Code = code;
    }

    public Courses(Integer id) {
        this.Id = id;
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String code) {
        Code = code;
    }
}
