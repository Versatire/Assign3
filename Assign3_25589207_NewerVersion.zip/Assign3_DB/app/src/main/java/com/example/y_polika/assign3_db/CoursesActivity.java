package com.example.y_polika.assign3_db;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import com.example.y_polika.assign3_db.ACTIVITIES_DB.ADBHelper;
import com.example.y_polika.assign3_db.COURSE_DB.CConfig;
import com.example.y_polika.assign3_db.COURSE_DB.CDBHelper;

import java.util.ArrayList;
import java.util.List;


public class CoursesActivity extends MainActivity {


    protected TextView courseTitleTextView;
    protected TextView courseCodeTextView;
    protected ListView assignListView;
    protected FloatingActionButton addAssignButton;
    protected Button exitCourseViewButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);

        //find the layout views and buttons

        courseTitleTextView = findViewById(R.id.courseTitleTextView);
        courseCodeTextView = findViewById(R.id.courseAssGradeTextView);
        assignListView = findViewById(R.id.assignListView);
        addAssignButton = findViewById(R.id.addAssignActionButton);
        exitCourseViewButton = findViewById(R.id.exitCourseViewButton);






    }


    @Override
    protected void onStart() {
        super.onStart();

        courseTitleTextView = findViewById(R.id.courseTitleTextView);
        courseCodeTextView = findViewById(R.id.courseAssGradeTextView);
        assignListView = findViewById(R.id.assignListView);
        addAssignButton = findViewById(R.id.addAssignActionButton);
        exitCourseViewButton = findViewById(R.id.exitCourseViewButton);

// get the course that was clicked from shared preferences
        SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.SharedPrefClickedCourse), Context.MODE_PRIVATE );
        String clickedCourse = sharedPreferences.getString(getString(R.string.clickedCourseTextNoId), null);

// set the course title and assignments list
        courseTitleTextView.setText(clickedCourse);

        loadAssignListView(clickedCourse);

//  set clickable button
        addAssignButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

            }
        });

    }



    protected void loadAssignListView(String courseCode){

        // Create a new object in the CDBHelper class called dbHelper
        ADBHelper dbHelper = new ADBHelper(this);
// creates a list called courses which will displayed the courses retrieved from courseDB
        List<Assignmen> allAssignments = dbHelper.getAllAssignments();

// creates a new ArrayList of type string called coursesListText to store courses retrieved
        ArrayList<String> assignListText = new ArrayList<>();

// Runs the index through courseID while index is less than size of the array for each row
        for(int i=0; i<allAssignments.size(); i++){
//Creates a an empty string called temp to temporarily store the title and the course code
            String temp = "";
            String check = allAssignments.get(i).getCourseCode();
            temp += allAssignments.get(i).getCourseCode() + "\n";
            temp += allAssignments.get(i).getAssignTitle() + "\n";
            temp += allAssignments.get(i).getAssignGrade();

// adds the temporary values stored in temp to nest item of courseListText
            if(check == courseCode) {
                assignListText.add(temp);
            }
        }

// ArrayAdapter used to display courses in ListView
        ArrayAdapter arrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, assignListText);
        coursesListView.setAdapter(arrayAdapter);
    }



    protected void loadAllAssignListView(){

        // Create a new object in the CDBHelper class called dbHelper
        ADBHelper dbHelper = new ADBHelper(this);
// creates a list called courses which will displayed the courses retrieved from courseDB
        List<Assignmen> allAssignments = dbHelper.getAllAssignments();

// creates a new ArrayList of type string called coursesListText to store courses retrieved
        ArrayList<String> assignListText = new ArrayList<>();

// Runs the index through courseID while index is less than size of the array for each row
        for(int i=0; i<allAssignments.size(); i++){
//Creates a an empty string called temp to temporarily store the title and the course code
            String temp = "";

            temp += allAssignments.get(i).getCourseCode() + "\n";
            temp += allAssignments.get(i).getAssignTitle() + "\n";
            temp += allAssignments.get(i).getAssignGrade();

// adds the temporary values stored in temp to nest item of courseListText

                assignListText.add(temp);

        }

// ArrayAdapter used to display courses in ListView
        ArrayAdapter arrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, assignListText);
        coursesListView.setAdapter(arrayAdapter);
    }

}


