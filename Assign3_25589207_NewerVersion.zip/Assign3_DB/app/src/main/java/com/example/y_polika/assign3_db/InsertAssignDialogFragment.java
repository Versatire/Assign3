package com.example.y_polika.assign3_db;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.y_polika.assign3_db.ACTIVITIES_DB.ADBHelper;
import com.example.y_polika.assign3_db.COURSE_DB.CDBHelper;

import static java.lang.Integer.parseInt;


public class InsertAssignDialogFragment extends DialogFragment {


    // Declare the editText fields and buttons
    protected EditText assignCCodeEditText;
    protected EditText assignTitleEditText;
    protected EditText assignGradeEditText;
    protected Button saveAssButton;
    protected Button canceladdAButton;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.fragment_insert_course, container, false);

        assignTitleEditText = view.findViewById(R.id.assignTitleEditText);
        assignGradeEditText = view.findViewById(R.id.assignGradeEditText);
        saveAssButton = view.findViewById(R.id.saveAssButton);
        canceladdAButton = view.findViewById(R.id.cancelAddAButton);


        saveAssButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String code = assignCCodeEditText.getText().toString();
                String title = assignTitleEditText.getText().toString();
                Integer grade = parseInt(assignGradeEditText.getText().toString());

                /* get the course that was clicked from shared prefferences
                SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.SharedPrefClickedCourse), Context.MODE_PRIVATE );
                String clickedCourse = sharedPreferences.getString(getString(R.string.courseCode), null);
                not recogrnizing function getSharedPreferences */



                ADBHelper adbHelper = new ADBHelper(getActivity());
                if(!(title.equals("") || grade.equals(""))){
                    adbHelper.insertAssignment(new Assignmen(code, title, grade));
                    ((CoursesActivity)getActivity()).loadAllAssignListView();
                    getDialog().dismiss();

                }

            }

        });

        canceladdAButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getDialog().dismiss();
            }
        });

        return view;


    }
}
