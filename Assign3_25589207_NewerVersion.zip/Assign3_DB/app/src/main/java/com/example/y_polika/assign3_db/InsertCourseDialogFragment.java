package com.example.y_polika.assign3_db;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.y_polika.assign3_db.COURSE_DB.CDBHelper;

public class InsertCourseDialogFragment extends DialogFragment {

// Declare the editText fields and buttons
    protected EditText courseTitleEditText;
    protected EditText courseCodeEditText;
    protected Button saveCourseButton;
    protected Button cancelCourseButton;

// the onCreateView function returns View
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {


// Have to specify which xml layout to link this too, which interface to inflate
// view of class View will be the return of the function onCreateView
        View view = inflater.inflate(R.layout.fragment_insert_course, container, false);

// find the EditText fields and buttons by id and connect to buttons in fragment
        courseTitleEditText = view.findViewById(R.id.courseTitleEditText);
        courseCodeEditText  = view.findViewById(R.id.courseCodeEditText);

        saveCourseButton = view.findViewById(R.id.saveCourseButton);
        cancelCourseButton = view.findViewById(R.id.cancelCourseButton);

        saveCourseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String title = courseTitleEditText.getText().toString();
                String code = courseCodeEditText.getText().toString();

                CDBHelper cdbHelper = new CDBHelper(getActivity());
                if(!(title.equals("") || code.equals(""))){
                    cdbHelper.insertCourse(new Courses(title, code));
                    ((MainActivity)getActivity()).loadListView();
                    getDialog().dismiss();

                }

            }
        });

        cancelCourseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getDialog().dismiss();
            }
        });

        return view;
    }


}
