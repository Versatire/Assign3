package com.example.y_polika.assign3_db;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.y_polika.assign3_db.COURSE_DB.CDBHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.function.LongToIntFunction;

public class MainActivity extends AppCompatActivity {

    protected ListView coursesListView;
    protected FloatingActionButton addCourseActionButton;

    public Integer courseIndex = null;
    public Long courseID = null;
    public Long assignID = null;
    public Object clickedCourseObject = null;
    public String clickedCourseCode = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        coursesListView = findViewById(R.id.coursesListView);
        addCourseActionButton = findViewById(R.id.addCourseActionButton);
    }



    @Override
    protected void onStart() {
        super.onStart();


        coursesListView = findViewById(R.id.coursesListView);
        addCourseActionButton = findViewById(R.id.addCourseActionButton);

//calls function loadLlistView
        loadListView();

        addCourseActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InsertCourseDialogFragment dialog = new InsertCourseDialogFragment();
                dialog.show(getSupportFragmentManager(), "InsertCourseFragment");
            }
        });


        coursesListView.setClickable(true);
        coursesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int i, long arg3) {

                Object object = coursesListView.getItemAtPosition(i);
                String str=(String)object;


                int index = (int) arg3;
                saveClickedCourse(index);

                goToCoursesActivity();
            }

        });
    }





    @Override
    protected void onResume() {
        super.onResume();

        coursesListView = findViewById(R.id.coursesListView);
        addCourseActionButton = findViewById(R.id.addCourseActionButton);

//calls function loadLlistView
        loadListView();

        addCourseActionButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                InsertCourseDialogFragment dialog = new InsertCourseDialogFragment();
                dialog.show(getSupportFragmentManager(), "InsertCourseFragment");

            }
        });



        coursesListView.setClickable(true);
        coursesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int i, long arg3) {

                Object object = coursesListView.getItemAtPosition(i);
                String str=(String)object;

                int index = (int)arg3;
                saveClickedCourse(index);

                goToCoursesActivity();
            }


        });



    }



    protected void loadListView(){

// Create a new object in the CDBHelper class called dbHelper
        CDBHelper dbHelper = new CDBHelper(this);
// creates a list called courses which will displayed the courses retrieved from courseDB
        List<Courses> courses = dbHelper.getAllCourses();

// creates a new ArrayList of type string called coursesListText to store courses retrieved
        ArrayList<String> coursesListText = new ArrayList<>();

// Runs the index through courseID while index is less than size of the array for each row
        for(int i=0; i<courses.size(); i++){
//Creates a an empty string called temp to temporarily store the title and the course code
            String temp = "";
            temp += courses.get(i).getTitle() + "\n";
            temp += courses.get(i).getCode();

// adds the temporary values stored in temp to nest item of courseListText
            coursesListText.add(temp);
        }

// ArrayAdapter used to display courses in ListView
        ArrayAdapter arrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, coursesListText);
        coursesListView.setAdapter(arrayAdapter);
    }



    protected void saveClickedCourse(int courseid){


// Create a new object in the CDBHelper class called dbHelper
        CDBHelper dbHelper = new CDBHelper(this);
// creates the courseCode from the passed ID
        String courseCode = dbHelper.getCodeByID(courseid);
        Courses clickedCourse = dbHelper.getCourseByCode(courseCode);

        String strID = Integer.toString(clickedCourse.getId());
        String title = clickedCourse.getTitle();
        String code = clickedCourse.getCode();

        String clickedCourseTextWithId;
        clickedCourseTextWithId = strID + " " + title + " " + code;

        String clickedCourseTextNoId = title + " " + code;


        SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.SharedPrefClickedCourse), Context.MODE_PRIVATE );
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(getString(R.string.courseCode), courseCode );
        editor.apply();

        SharedPreferences.Editor editor2 = sharedPreferences.edit();
        editor2.putString(getString(R.string.courseCode), clickedCourseTextWithId );
        editor2.apply();


        SharedPreferences.Editor editor3 = sharedPreferences.edit();
        editor3.putString(getString(R.string.courseCode), clickedCourseTextNoId );
        editor3.apply();


    }


    protected void goToCoursesActivity()
    {

        Intent intent = new Intent(MainActivity.this, CoursesActivity.class);
        startActivity(intent);

    }



}
